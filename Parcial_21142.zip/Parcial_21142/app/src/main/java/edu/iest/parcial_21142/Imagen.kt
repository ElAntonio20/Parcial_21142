package edu.iest.parcial_21142

data class Imagen (

    var texto: String,
    var imagen: Int
)